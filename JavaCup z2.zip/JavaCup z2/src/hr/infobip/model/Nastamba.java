package hr.infobip.model;

import java.util.List;

public class Nastamba {
    private Integer id;
    private String naziv;
    private List<Zivotinja> popisZivotinja;

    public Nastamba(Integer id, String naziv) {
        this.id = id;
        this.naziv = naziv;
    }

    public List<Zivotinja> getPopisZivotinja() {
        return popisZivotinja;
    }

    public void setPopisZivotinja(List<Zivotinja> popisZivotinja) {
        this.popisZivotinja = popisZivotinja;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "\nNastamba{" +
                "id=" + id +
                ", naziv='" + naziv + '\'' +
                ", popisZivotinja=" + popisZivotinja +
                '}';
    }
}
