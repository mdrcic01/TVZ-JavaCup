package hr.infobip.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Timaritelj {
    private Integer id;
    private String prezime;
    private String ime;
    private LocalDate datumRodenja;
    private List<Nastamba> popisNastambi;

    public Timaritelj(Integer id, String prezime, String ime, String datumRodenja, List<Nastamba> popisNastambi) {
        this.id = id;
        this.prezime = prezime;
        this.ime = ime;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d.M.yyyy.");
        LocalDate date = LocalDate.parse(datumRodenja, formatter);
        this.datumRodenja = date;
        this.popisNastambi = popisNastambi;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public LocalDate getDatumRodenja() {
        return datumRodenja;
    }

    public void setDatumRodenja(LocalDate datumRodenja) {
        this.datumRodenja = datumRodenja;
    }

    public List<Nastamba> getPopisNastambi() {
        return popisNastambi;
    }

    public void setPopisNastambi(List<Nastamba> popisNastambi) {
        this.popisNastambi = popisNastambi;
    }

    @Override
    public String toString() {
        return "Ime: " + ime + " " + prezime + "\nDatum rodenja: " + datumRodenja + "\nPopis nnastambi: " + popisNastambi;
    }
}
