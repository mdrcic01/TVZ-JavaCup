package hr.infobip.model;

public class Zivotinja {
    private Nastamba kavez;
    private Integer id;
    private String ime;
    private String vrsta;

    public Zivotinja(Integer id, String ime, String vrsta) {
        this.id = id;
        this.ime = ime;
        this.vrsta = vrsta;
    }

    @Override
    public String toString() {
        return "\nZivotinja{" +
                "kavez=" + kavez +
                ", id=" + id +
                ", ime='" + ime + '\'' +
                ", vrsta='" + vrsta + '\'' +
                '}';
    }

    public Nastamba getKavez() {
        return kavez;
    }

    public void setKavez(Nastamba kavez) {
        this.kavez = kavez;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getVrsta() {
        return vrsta;
    }

    public void setVrsta(String vrsta) {
        this.vrsta = vrsta;
    }
}
