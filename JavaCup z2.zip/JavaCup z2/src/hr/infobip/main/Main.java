package hr.infobip.main;

import hr.infobip.model.Nastamba;
import hr.infobip.model.Timaritelj;
import hr.infobip.model.Zivotinja;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        Integer animalNo = userInput.nextInt();
        userInput.nextLine();
        List<Zivotinja> animalList = new ArrayList<>();
        List<Nastamba> cageList = new ArrayList<>();
        List<Timaritelj> workerList = new ArrayList<>();

        //unos zivotinja
        for(int i = 0; i<animalNo; i++){
            Integer tmpID = userInput.nextInt();
            userInput.nextLine();
            String tmpName = userInput.nextLine();
            String tmpType = userInput.nextLine();
            Zivotinja tmpAnimal = new Zivotinja(tmpID, tmpName, tmpType);
            animalList.add(tmpAnimal);
        }
        //unos nastambi
        Integer cageNo = userInput.nextInt();
        for(int i = 0; i<cageNo; i++){
            Integer cageID = userInput.nextInt();
            userInput.nextLine();
            String tmpName = userInput.nextLine();
            Nastamba tmpCage = new Nastamba(cageID, tmpName);
            Integer subAnimalNo = userInput.nextInt();
            List<Zivotinja> animalSublist = new ArrayList<>();
            for(int j = 0; j<subAnimalNo; j++){
                Integer animalID = userInput.nextInt();
                for(Zivotinja animal : animalList){
                    if(animal.getId().equals(animalID)){
                        animalSublist.add(animal);
                    }
                }
                //animalSublist.add(animalList.get(animalID-1));
                userInput.nextLine();
            }
            tmpCage.setPopisZivotinja(animalSublist);
            cageList.add(tmpCage);
        }
        //unos radnika
        Integer workerNo = userInput.nextInt();
        for(int i = 0; i<workerNo; i++){
            Integer tmpID = userInput.nextInt();
            userInput.nextLine();
            String tmpName = userInput.nextLine();
            String tmpSurname = userInput.nextLine();
            String birthday = userInput.nextLine();
            List<Nastamba> cageSublist = new ArrayList<>();
            Integer subCageNo = userInput.nextInt();
            for(int j = 0; j<subCageNo; j++){
                Integer cageID = userInput.nextInt();
                for(Nastamba cage : cageList){
                    if(cage.getId().equals(cageID)){
                        cageSublist.add(cage);
                    }
                }
                userInput.nextLine();
            }
            Timaritelj worker = new Timaritelj(tmpID, tmpName, tmpSurname, birthday, cageSublist);
            workerList.add(worker);
        }
        Integer foodAmount = userInput.nextInt();
        userInput.nextLine();
        workerList.sort(Comparator.comparing(o -> o.getDatumRodenja()));
        Integer animalsFed = 0;

        for(Timaritelj worker : workerList){
            //System.out.println(worker.getPrezime() + " " + worker.getIme());
            worker.getPopisNastambi().sort(Comparator.comparing(o -> o.getPopisZivotinja().size()));
            /*for(Nastamba cage : worker.getPopisNastambi()){
                System.out.println(cage.getPopisZivotinja().size());
            }*/
        }


        for(int i = workerList.size()-1; i>=0; i--){
            for(int j = workerList.get(i).getPopisNastambi().size()-1; j>=0; j--){
                if(foodAmount > 0){
                    Integer fed = workerList.get(i).getPopisNastambi().get(j).getPopisZivotinja().size();
                    //System.out.println("nahranjeno je " + fed + " zivotinja");
                    animalsFed += fed;
                    foodAmount--;
                }
                else{
                    break;
                }
            }
            if(foodAmount <= 0){
                break;
            }
        }
        System.out.println("Nahranjeno je " + animalsFed + " zivotinja/e.");








    }
}
