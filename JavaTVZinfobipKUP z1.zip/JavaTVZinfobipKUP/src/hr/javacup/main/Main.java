package hr.javacup.main;

import hr.javacup.model.FileUtility;
import hr.javacup.model.Imenik;
import hr.javacup.model.SMS;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        /*BigDecimal domaceTarife = userInput.nextBigDecimal();
        BigDecimal straneTarife = userInput.nextBigDecimal();
        domaceTarife = domaceTarife.setScale(2, RoundingMode.CEILING);
        straneTarife = straneTarife.setScale(2, RoundingMode.CEILING);
        Double homeTariff = domaceTarife.doubleValue();
        Double foreignTariff = straneTarife.doubleValue();*/
        Double homeTariff = userInput.nextDouble();
        Double foreignTariff = userInput.nextDouble();
        List<Imenik> phonebookList = null;
        try {
             phonebookList = FileUtility.getPhonebook();
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<SMS> smsList = null;
        try{
            smsList = FileUtility.getSMS();
        }catch (IOException e){
            e.printStackTrace();
        }

        /*for (int i = 0; i< phonebookList.size(); i++){
            System.out.println(phonebookList.get(i));
        }
        for (int i = 0; i< smsList.size(); i++){
            System.out.println(smsList.get(i));
        }*/

        System.out.println("Domaca tarifa: " + homeTariff);
        System.out.println("Strana tarifa: " + foreignTariff);

        Integer succesfullySent = 0;
        Map<String, String> unsentMessages = new HashMap<>();
        for(int i=0; i< smsList.size(); i++){
            Boolean foreign = false;
            Double tariff = null;
            Imenik sender = null;
            Imenik recipient = null;
            for(int j = 0; j< phonebookList.size(); j++){
                if(smsList.get(i).getSenderPhonenumber().equals(phonebookList.get(j).getPhoneNumber())){
                    sender = phonebookList.get(j);
                }
                if(smsList.get(i).getRecipientPhonenumber().equals(phonebookList.get(j).getPhoneNumber())){
                    recipient = phonebookList.get(j);
                }
            }
            if(smsList.get(i).getSenderCountryCode().equals(smsList.get(i).getRecipientCountryCode()) ){
                tariff = homeTariff;
            }
            else {
                tariff = foreignTariff;
                foreign = true;
            }
            if(sender.getBudget().compareTo(tariff) >= 0){
                succesfullySent++;
                sender.setBudget(sender.getBudget()-tariff);
                if(foreign == true){
                    sender.foreignMessages++;
                }
                else{
                    sender.localMessages++;
                }
            }else{
                unsentMessages.put(sender.getPhoneNumber(), smsList.get(i).getMessage());
            }
        }

        System.out.println("Uspjesno poslano: " + succesfullySent + " poruka!");
        for (Map.Entry<String, String> entry : unsentMessages.entrySet()) {
            System.out.println(entry.getKey()+": "+entry.getValue());
        }

        //najvise lokalnih poruka
        Integer mostMessages = 0;
        Imenik mostMessagesPerson = null;
        for(Imenik person : phonebookList){
            if(person.localMessages > mostMessages){
                mostMessagesPerson = person;
                mostMessages = person.localMessages;
            }
        }
        System.out.println("Najvise lokalnih poruka: " + mostMessagesPerson.getFirstName() +
                " " + mostMessagesPerson.getLastName());

        //najvise stranih poruka
        Integer mostFMessages = 0;
        Imenik mostFMessagesPerson = null;
        for(Imenik person : phonebookList){
            if(person.foreignMessages > mostFMessages){
                mostFMessagesPerson = person;
                mostFMessages = person.foreignMessages;
            }
        }
        System.out.println("Najvise stranih poruka: " + mostFMessagesPerson.getFirstName() +
                " " + mostFMessagesPerson.getLastName());

    }
}
