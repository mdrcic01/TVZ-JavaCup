package hr.javacup.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FileUtility {

    private static final String PHONEBOOK_FILE_PATH = "files/imenik.txt";
    private static final String SMS_FILE_PATH = "files/sms.txt";

    public static List<Imenik> getPhonebook() throws IOException {
        FileReader reader = new FileReader(PHONEBOOK_FILE_PATH);
        BufferedReader br = new BufferedReader(reader);
        String readLine;
        List<Imenik> phonebookList = new ArrayList<>();

        while ((readLine = br.readLine()) != null){
            String tmpPhonenumber = readLine;
            String countryCode = tmpPhonenumber.substring(0,3);
            String phonenumber = tmpPhonenumber.substring(3);
            String tmpName = br.readLine();
            String[] nameSurname = tmpName.split(" ");
            String firstName = nameSurname[0];
            String lastName = nameSurname[1];
            //String firstName = tmpName;
            //String lastName = tmpName;
            String birthday = br.readLine();
            String email = br.readLine();
            String tmpSaldo = br.readLine();
            String saldoKN = tmpSaldo.replaceAll("[^0-9.]", "");
            Double saldo = Double.parseDouble(saldoKN);
            Imenik tmpPhonebook = new Imenik(countryCode, phonenumber, firstName, lastName, birthday, email, saldo);
            phonebookList.add(tmpPhonebook);
        }
        return phonebookList;
    }

    public static List<SMS> getSMS() throws IOException {
        FileReader reader = new FileReader(SMS_FILE_PATH);
        BufferedReader br = new BufferedReader(reader);
        String readLine;
        List<SMS> smsList = new ArrayList<>();

        while ((readLine = br.readLine()) != null){
            String tmpPhonenumberSender = readLine;
            String countryCodeS = tmpPhonenumberSender.substring(0,3);
            String phonenumberS = tmpPhonenumberSender.substring(3);
            String tmpPhonenumberRecipient = br.readLine();
            String countryCodeR = tmpPhonenumberRecipient.substring(0,3);
            String phonenumberR = tmpPhonenumberRecipient.substring(3);
            String message = br.readLine();

            SMS tmpSMS = new SMS(phonenumberS, phonenumberR, countryCodeS, countryCodeR, message);
            smsList.add(tmpSMS);
        }
        return smsList;
    }
}
