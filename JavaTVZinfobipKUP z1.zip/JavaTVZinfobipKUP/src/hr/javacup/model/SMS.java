package hr.javacup.model;

public class SMS {
    private String senderPhonenumber;
    private String recipientPhonenumber;
    private String senderCountryCode;
    private String recipientCountryCode;
    private String message;

    public SMS(String senderPhonenumber, String recipientPhonenumber, String senderCountryCode,
               String recipientCountryCode, String message) {
        this.senderPhonenumber = senderPhonenumber;
        this.recipientPhonenumber = recipientPhonenumber;
        this.senderCountryCode = senderCountryCode;
        this.recipientCountryCode = recipientCountryCode;
        this.message = message;
    }

    @Override
    public String toString() {
        return "SMS{" +
                "senderPhonenumber='" + senderPhonenumber + '\'' +
                ", recipientPhonenumber='" + recipientPhonenumber + '\'' +
                ", senderCountryCode='" + senderCountryCode + '\'' +
                ", recipientCountryCode='" + recipientCountryCode + '\'' +
                ", message='" + message + '\'' +
                '}';
    }

    public String getSenderPhonenumber() {
        return senderPhonenumber;
    }

    public void setSenderPhonenumber(String senderPhonenumber) {
        this.senderPhonenumber = senderPhonenumber;
    }

    public String getRecipientPhonenumber() {
        return recipientPhonenumber;
    }

    public void setRecipientPhonenumber(String recipientPhonenumber) {
        this.recipientPhonenumber = recipientPhonenumber;
    }

    public String getSenderCountryCode() {
        return senderCountryCode;
    }

    public void setSenderCountryCode(String senderCountryCode) {
        this.senderCountryCode = senderCountryCode;
    }

    public String getRecipientCountryCode() {
        return recipientCountryCode;
    }

    public void setRecipientCountryCode(String recipientCountryCode) {
        this.recipientCountryCode = recipientCountryCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
